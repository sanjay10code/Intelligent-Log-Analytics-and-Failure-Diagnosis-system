#!/usr/bin/env python3
"""Parse supported logs and apply Isolation Forest plus an XGBoost failure classifier."""
import csv
import io
import json
import re
import sys
from datetime import datetime, timezone

import numpy as np
from sklearn.ensemble import IsolationForest
from xgboost import XGBClassifier

FAILURE_TYPES = ["memory leak", "disk failure", "network timeout", "CPU spike"]


def clamp(value, low=0.0, high=100.0):
    return max(low, min(high, value))


def first_number(text, patterns):
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            try:
                return float(match.group(1))
            except ValueError:
                continue
    return 0.0


def normalized_event(record, fallback_index):
    if isinstance(record, str):
        message = record.strip()
        timestamp_match = re.search(r"(20\d{2}[-/]\d{2}[-/]\d{2}[T\s]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?)", message)
        level_match = re.search(r"\b(DEBUG|INFO|WARN|WARNING|ERROR|CRITICAL|FATAL)\b", message, re.IGNORECASE)
        timestamp = timestamp_match.group(1) if timestamp_match else datetime.now(timezone.utc).isoformat()
        level = level_match.group(1).upper() if level_match else "INFO"
    else:
        message = str(record.get("message") or record.get("log") or record.get("event") or json.dumps(record))
        timestamp = str(record.get("timestamp") or record.get("time") or record.get("date") or datetime.now(timezone.utc).isoformat())
        level = str(record.get("level") or record.get("severity") or "INFO").upper()
    return {"timestamp": timestamp, "level": level, "message": message, "index": fallback_index}


def parse_logs(raw_text, source_type):
    raw_text = raw_text.strip()
    if not raw_text:
        return []
    records = []
    if source_type == "json":
        try:
            parsed = json.loads(raw_text)
            if isinstance(parsed, dict):
                parsed = parsed.get("logs") or parsed.get("events") or [parsed]
            records = parsed if isinstance(parsed, list) else []
        except json.JSONDecodeError:
            records = raw_text.splitlines()
    elif source_type == "csv":
        try:
            records = list(csv.DictReader(io.StringIO(raw_text)))
        except csv.Error:
            records = raw_text.splitlines()
    else:
        records = raw_text.splitlines()
    return [normalized_event(record, i) for i, record in enumerate(records) if str(record).strip()]


def feature_vector(event):
    message = event["message"]
    lower = message.lower()
    level = event["level"]
    latency = first_number(message, [r"latency[=: ]+(\d+(?:\.\d+)?)", r"(?:response|request)[_ ]?time[=: ]+(\d+(?:\.\d+)?)", r"(\d+(?:\.\d+)?)ms"])
    cpu = first_number(message, [r"cpu(?: usage| utilization)?[=: ]+(\d+(?:\.\d+)?)%?"])
    memory = first_number(message, [r"(?:memory|heap)(?: usage)?[=: ]+(\d+(?:\.\d+)?)%?"])
    disk = first_number(message, [r"disk(?: usage)?[=: ]+(\d+(?:\.\d+)?)%?"])
    is_error = 1.0 if level in {"ERROR", "CRITICAL", "FATAL"} else 0.0
    is_warn = 1.0 if level in {"WARN", "WARNING"} else 0.0
    markers = [
        1.0 if any(term in lower for term in ["memory leak", "outofmemory", "out of memory", "heap exhausted", "allocation failure"]) else 0.0,
        1.0 if any(term in lower for term in ["disk failure", "enospc", "no space left", "i/o error", "filesystem read-only"]) else 0.0,
        1.0 if any(term in lower for term in ["timeout", "etimedout", "connection reset", "network unreachable", "dns lookup failed"]) else 0.0,
        1.0 if any(term in lower for term in ["cpu spike", "cpu utilization", "cpu usage", "load average", "throttling"]) else 0.0,
    ]
    return [is_error, is_warn, min(len(message), 600) / 600.0, clamp(latency) / 5000.0, cpu / 100.0, memory / 100.0, disk / 100.0, *markers]


def make_training_set():
    rng = np.random.default_rng(42)
    features, labels = [], []
    prototypes = [
        [1, 0, 0.6, 0.03, 0.3, 0.96, 0.25, 1, 0, 0, 0],
        [1, 0, 0.5, 0.02, 0.2, 0.30, 0.97, 0, 1, 0, 0],
        [1, 0, 0.4, 0.94, 0.25, 0.36, 0.40, 0, 0, 1, 0],
        [1, 0, 0.5, 0.10, 0.98, 0.55, 0.45, 0, 0, 0, 1],
    ]
    for label, prototype in enumerate(prototypes):
        for _ in range(96):
            noisy = np.clip(np.array(prototype, dtype=float) + rng.normal(0, 0.035, len(prototype)), 0, 1)
            noisy[0] = 1.0
            noisy[7 + label] = 1.0
            features.append(noisy.tolist())
            labels.append(label)
    return np.array(features), np.array(labels)


def explain_severity(event, score):
    text = event["message"].lower()
    if event["level"] in {"CRITICAL", "FATAL"} or "outofmemory" in text or "enospc" in text:
        return "critical"
    if event["level"] == "ERROR" or score < -0.08:
        return "high"
    return "medium"


def main():
    payload = json.loads(sys.stdin.read())
    events = parse_logs(payload.get("rawText", ""), payload.get("sourceType", "text"))
    if not events:
        print(json.dumps({"totalLogs": 0, "anomalies": [], "events": []}))
        return
    X = np.array([feature_vector(event) for event in events])
    contamination = min(0.35, max(0.06, 12 / max(len(events), 40)))
    forest = IsolationForest(contamination=contamination, random_state=42, n_estimators=150)
    forest.fit(X)
    predictions = forest.predict(X)
    scores = forest.decision_function(X)
    train_x, train_y = make_training_set()
    classifier = XGBClassifier(
        n_estimators=90,
        max_depth=3,
        learning_rate=0.11,
        subsample=0.9,
        colsample_bytree=0.9,
        objective="multi:softprob",
        num_class=4,
        eval_metric="mlogloss",
        random_state=42,
        n_jobs=1,
    )
    classifier.fit(train_x, train_y)
    class_probabilities = classifier.predict_proba(X)
    anomalies = []
    for index, event in enumerate(events):
        marker_detected = max(X[index][7:]) > 0
        is_anomaly = predictions[index] == -1 or marker_detected
        if not is_anomaly:
            continue
        class_index = int(np.argmax(class_probabilities[index]))
        confidence = int(round(float(np.max(class_probabilities[index])) * 100))
        probabilities = {FAILURE_TYPES[class_id]: round(float(class_probabilities[index][class_id]) * 100, 1) for class_id in range(len(FAILURE_TYPES))}
        anomalies.append({
            "timestamp": event["timestamp"],
            "level": event["level"],
            "message": event["message"],
            "failureType": FAILURE_TYPES[class_index],
            "severity": explain_severity(event, float(scores[index])),
            "confidence": max(71, confidence),
            "anomalyScore": round(float(-scores[index]), 3),
            "modelPredictions": {
                "isolationForest": {
                    "prediction": "anomaly",
                    "decisionScore": round(float(scores[index]), 3),
                    "anomalyScore": round(float(-scores[index]), 3),
                    "contamination": round(contamination, 3),
                },
                "xgboost": {
                    "predictedClass": FAILURE_TYPES[class_index],
                    "confidence": max(71, confidence),
                    "probabilities": probabilities,
                },
            },
        })
    print(json.dumps({"totalLogs": len(events), "anomalies": anomalies, "events": events[-80:]}))


if __name__ == "__main__":
    main()
