import { desc, eq, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { analysisRuns, incidents, InsertAnalysisRun, InsertIncident, InsertUser, users } from "../drizzle/schema";
import { ENV } from './_core/env';
import type { ModelPredictions } from "./services/logAnalysis";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function createAnalysisRun(run: Omit<InsertAnalysisRun, "id" | "createdAt">) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.insert(analysisRuns).values(run);
  return result[0].insertId;
}

type PersistedAnalysisIncident = {
  timestamp: string;
  level: string;
  severity: "critical" | "high" | "medium" | "low";
  failureType: "memory leak" | "disk failure" | "network timeout" | "CPU spike";
  confidence: number;
  anomalyScore: number;
  modelPredictions: ModelPredictions;
  message: string;
  diagnosis: string;
  recommendations: string[];
};

export async function createIncidents(analysisRunId: number, sourceIncidents: PersistedAnalysisIncident[]) {
  const db = await getDb();
  if (!db || sourceIncidents.length === 0) return [];
  const values: InsertIncident[] = sourceIncidents.map(incident => ({
    analysisRunId,
    eventTimestamp: incident.timestamp.slice(0, 64),
    level: incident.level.slice(0, 24),
    severity: incident.severity,
    failureType: incident.failureType,
    confidence: Math.round(incident.confidence),
    anomalyScore: String(incident.anomalyScore),
    modelPredictions: incident.modelPredictions,
    logMessage: incident.message,
    diagnosis: incident.diagnosis,
    recommendations: incident.recommendations,
  }));
  await db.insert(incidents).values(values);
  return db.select().from(incidents).where(eq(incidents.analysisRunId, analysisRunId)).orderBy(desc(incidents.id));
}

export async function listIncidents({ limit }: { limit: number }) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(incidents).orderBy(desc(incidents.id)).limit(limit);
}

export async function getIncidentById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(incidents).where(eq(incidents.id, id)).limit(1);
  return result[0];
}

export async function getIncidentSummary() {
  const db = await getDb();
  if (!db) return { totalIncidents: 0, openIncidents: 0, distribution: [] as Array<{ failureType: string; count: number }> };
  const [total] = await db.select({ count: sql<number>`count(*)` }).from(incidents);
  const [open] = await db.select({ count: sql<number>`count(*)` }).from(incidents).where(eq(incidents.status, "open"));
  const distribution = await db.select({ failureType: incidents.failureType, count: sql<number>`count(*)` }).from(incidents).groupBy(incidents.failureType);
  return { totalIncidents: Number(total?.count ?? 0), openIncidents: Number(open?.count ?? 0), distribution: distribution.map(item => ({ ...item, count: Number(item.count) })) };
}
