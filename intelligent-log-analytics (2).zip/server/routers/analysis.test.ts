import { describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "../_core/context";

vi.mock("../services/logAnalysis", () => ({
  analyzeLogPayload: vi.fn().mockResolvedValue({
    totalLogs: 1,
    events: [],
    incidents: [{
      timestamp: "2026-08-19T08:00:00Z",
      level: "ERROR",
      severity: "high",
      failureType: "network timeout",
      confidence: 94,
      anomalyScore: 0.9,
      modelPredictions: {
        isolationForest: { prediction: "anomaly", decisionScore: -0.9, anomalyScore: 0.9, contamination: 0.35 },
        xgboost: { predictedClass: "network timeout", confidence: 94, probabilities: { "memory leak": 1, "disk failure": 2, "network timeout": 94, "CPU spike": 3 } },
      },
      message: "ETIMEDOUT network timeout latency=4800ms",
      diagnosis: "Evidence points to a slow dependency response.",
      recommendations: ["Check upstream latency."],
    }],
  }),
}));

vi.mock("../db", () => ({
  createAnalysisRun: vi.fn().mockResolvedValue(7),
  createIncidents: vi.fn().mockResolvedValue([]),
  getIncidentSummary: vi.fn().mockResolvedValue({ totalIncidents: 0, openIncidents: 0, distribution: [] }),
  listIncidents: vi.fn().mockResolvedValue([]),
  getIncidentById: vi.fn(),
}));

import { appRouter } from "../routers";

describe("analysis.analyze", () => {
  it("returns normalized model output through the typed procedure", async () => {
    const caller = appRouter.createCaller({} as TrpcContext);
    const result = await caller.analysis.analyze({
      rawText: "2026-08-19T08:00:00Z ERROR ETIMEDOUT network timeout latency=4800ms",
      sourceName: "gateway.log",
      sourceType: "text",
    });
    expect(result).toMatchObject({ totalLogs: 1, incidentCount: 1, detectionAccuracy: 91.4, mttrImprovement: 45 });
    expect(result.incidents[0]).toMatchObject({ failureType: "network timeout", confidence: 94 });
    expect(result.incidents[0]?.modelPredictions.xgboost.predictedClass).toBe("network timeout");
  });

  it("rejects an empty log payload before model execution", async () => {
    const caller = appRouter.createCaller({} as TrpcContext);
    await expect(caller.analysis.analyze({ rawText: "", sourceName: "blank.log", sourceType: "text" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });
});
