import { spawn } from "child_process";
import path from "path";
import { describe, expect, it } from "vitest";

const projectRoot = path.resolve(import.meta.dirname, "../..");
const scriptPath = path.join(projectRoot, "scripts", "analyze_logs.py");

async function runPythonAnalysis(rawText: string, sourceType: "text" | "json" | "csv") {
  const stdout = await new Promise<string>((resolve, reject) => {
    const child = spawn("python3", [scriptPath], { stdio: ["pipe", "pipe", "pipe"] });
    let output = "";
    let error = "";
    child.stdout.on("data", chunk => { output += chunk.toString(); });
    child.stderr.on("data", chunk => { error += chunk.toString(); });
    child.on("error", reject);
    child.on("close", code => code === 0 ? resolve(output) : reject(new Error(error)));
    child.stdin.write(JSON.stringify({ rawText, sourceType }));
    child.stdin.end();
  });
  return JSON.parse(stdout) as { totalLogs: number; anomalies: Array<{ failureType: string; severity: string; modelPredictions: { isolationForest: { prediction: string }; xgboost: { probabilities: Record<string, number> } } }> };
}

describe("Python log analysis engine", () => {
  it("parses plain text logs and recognizes all required failure classes", async () => {
    const input = [
      "2026-08-19T08:00:00Z ERROR OutOfMemoryError memory leak memory=98%",
      "2026-08-19T08:01:00Z CRITICAL ENOSPC disk failure disk=99%",
      "2026-08-19T08:02:00Z ERROR ETIMEDOUT network timeout latency=4800ms",
      "2026-08-19T08:03:00Z WARN CPU spike cpu usage=98%",
    ].join("\n");
    const result = await runPythonAnalysis(input, "text");
    expect(result.totalLogs).toBe(4);
    expect(result.anomalies.map(item => item.failureType)).toEqual(expect.arrayContaining(["memory leak", "disk failure", "network timeout", "CPU spike"]));
    expect(result.anomalies[0]?.modelPredictions.isolationForest.prediction).toBe("anomaly");
    expect(result.anomalies[0]?.modelPredictions.xgboost.probabilities).toHaveProperty("memory leak");
  }, 20_000);

  it("normalizes JSON and CSV records before applying anomaly detection", async () => {
    const json = JSON.stringify([{ timestamp: "2026-08-19T09:00:00Z", level: "ERROR", message: "ETIMEDOUT network timeout latency=4900ms" }]);
    const csv = "timestamp,level,message\n2026-08-19T09:00:00Z,ERROR,OutOfMemoryError memory leak memory=98%";
    await expect(runPythonAnalysis(json, "json")).resolves.toMatchObject({ totalLogs: 1, anomalies: expect.any(Array) });
    await expect(runPythonAnalysis(csv, "csv")).resolves.toMatchObject({ totalLogs: 1, anomalies: expect.any(Array) });
  }, 20_000);
});
