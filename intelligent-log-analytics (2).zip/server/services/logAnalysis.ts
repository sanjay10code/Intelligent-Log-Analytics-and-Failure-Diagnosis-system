import { spawn } from "child_process";
import path from "path";
import { listLLMModels, invokeLLM } from "../_core/llm";
import { fallbackDiagnosis, getIncidentPlaybook, type FailureType, type Severity } from "./incidentUtils";

export type LogSourceType = "text" | "json" | "csv";

export type AnalysisIncident = {
  timestamp: string;
  level: string;
  message: string;
  failureType: FailureType;
  severity: Severity;
  confidence: number;
  anomalyScore: number;
  modelPredictions: ModelPredictions;
  diagnosis: string;
  recommendations: string[];
};

export type ModelPredictions = {
  isolationForest: {
    prediction: "anomaly";
    decisionScore: number;
    anomalyScore: number;
    contamination: number;
  };
  xgboost: {
    predictedClass: FailureType;
    confidence: number;
    probabilities: Record<FailureType, number>;
  };
};

type PythonResult = Omit<AnalysisIncident, "diagnosis" | "recommendations">;

type RawAnalysis = {
  totalLogs: number;
  anomalies: PythonResult[];
  events: Array<{ timestamp: string; level: string; message: string }>;
};

function callPython(payload: { rawText: string; sourceType: LogSourceType }): Promise<RawAnalysis> {
  const scriptPath = path.join(process.cwd(), "scripts", "analyze_logs.py");
  return new Promise((resolve, reject) => {
    const child = spawn("python3", [scriptPath], { stdio: ["pipe", "pipe", "pipe"] });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", chunk => { stdout += chunk.toString(); });
    child.stderr.on("data", chunk => { stderr += chunk.toString(); });
    child.on("error", reject);
    child.on("close", code => {
      if (code !== 0) {
        reject(new Error(`Python analysis service exited with code ${code}: ${stderr.slice(-500)}`));
        return;
      }
      try {
        resolve(JSON.parse(stdout) as RawAnalysis);
      } catch (error) {
        reject(new Error(`Python analysis service returned invalid JSON: ${String(error)}`));
      }
    });
    child.stdin.write(JSON.stringify(payload));
    child.stdin.end();
  });
}

async function llmDiagnosis(incident: PythonResult): Promise<string> {
  const baseline = fallbackDiagnosis(incident.failureType, incident.severity, incident.message);
  try {
    const { data: models } = await listLLMModels();
    const model = models.find(item => item.id === "gpt-5-mini")?.id ?? models[0]?.id;
    if (!model) return baseline;
    const response = await invokeLLM({
      model,
      messages: [
        {
          role: "system",
          content: "You are a senior site-reliability engineer. Write a concise, evidence-bound root-cause explanation. Do not claim certainty. Return only a single paragraph of 60 to 95 words.",
        },
        {
          role: "user",
          content: JSON.stringify({
            failureType: incident.failureType,
            severity: incident.severity,
            anomalyScore: incident.anomalyScore,
            message: incident.message,
          }),
        },
      ],
      maxTokens: 220,
    });
    const content = response.choices[0]?.message.content;
    return typeof content === "string" && content.trim() ? content.trim() : baseline;
  } catch (error) {
    console.warn("[Log analysis] LLM diagnosis unavailable; using deterministic diagnosis.", error);
    return baseline;
  }
}

export async function analyzeLogPayload(payload: { rawText: string; sourceType: LogSourceType }) {
  const raw = await callPython(payload);
  const incidents = await Promise.all(raw.anomalies.slice(0, 12).map(async incident => ({
    ...incident,
    diagnosis: await llmDiagnosis(incident),
    recommendations: getIncidentPlaybook(incident.failureType).steps,
  })));
  return { ...raw, incidents };
}
