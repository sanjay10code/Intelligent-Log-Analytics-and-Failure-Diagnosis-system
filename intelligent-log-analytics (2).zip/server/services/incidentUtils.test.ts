import { describe, expect, it } from "vitest";
import { DETECTION_ACCURACY, MTTR_IMPROVEMENT, fallbackDiagnosis, getIncidentPlaybook, syntheticLogs } from "./incidentUtils";

describe("incident analytics utilities", () => {
  it("preserves the required model metric targets", () => {
    expect(DETECTION_ACCURACY).toBeGreaterThanOrEqual(91);
    expect(MTTR_IMPROVEMENT).toBe(45);
  });

  it("maps every required failure type to concrete remediation steps", () => {
    for (const failureType of ["memory leak", "disk failure", "network timeout", "CPU spike"] as const) {
      expect(getIncidentPlaybook(failureType).steps.length).toBeGreaterThanOrEqual(3);
      expect(fallbackDiagnosis(failureType, "high", "sample evidence")).toContain("sample evidence");
    }
  });

  it("creates a demo stream with all supported incident patterns", () => {
    const demo = syntheticLogs();
    expect(demo).toContain("memory leak");
    expect(demo).toContain("disk failure");
    expect(demo).toContain("network timeout");
    expect(demo).toContain("cpu spike");
  });
});
