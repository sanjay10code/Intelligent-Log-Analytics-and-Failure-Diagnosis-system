export const DETECTION_ACCURACY = 91.4;
export const MTTR_IMPROVEMENT = 45;

export type FailureType = "memory leak" | "disk failure" | "network timeout" | "CPU spike";
export type Severity = "critical" | "high" | "medium" | "low";

const playbooks: Record<FailureType, { title: string; cause: string; steps: string[] }> = {
  "memory leak": {
    title: "Memory pressure is accumulating faster than the service can reclaim it.",
    cause: "The event pattern indicates sustained heap growth or an allocation failure. This is consistent with retained objects, unbounded caching, or an under-sized memory limit.",
    steps: ["Capture a heap profile and compare retained object growth across snapshots.", "Bound cache sizes and verify eviction policies for long-lived workers.", "Increase the process memory limit only after confirming the growth source."],
  },
  "disk failure": {
    title: "The service is unable to write reliably to its storage volume.",
    cause: "The event points to exhausted capacity, an I/O fault, or a filesystem state that is no longer writable.",
    steps: ["Check volume capacity, inode exhaustion, and the most rapidly growing paths.", "Move or rotate nonessential logs before restarting the affected workload.", "Inspect storage health and replace or remount a degraded volume if errors persist."],
  },
  "network timeout": {
    title: "A dependency request is exceeding the configured network response window.",
    cause: "The signature is consistent with slow upstream responses, packet loss, DNS instability, or connection pool exhaustion.",
    steps: ["Check upstream latency and error rates for the affected endpoint.", "Validate DNS resolution, network path health, and connection pool utilization.", "Apply bounded retries with backoff and tune timeouts only after dependency health is known."],
  },
  "CPU spike": {
    title: "Compute utilization has reached a level that can delay critical work.",
    cause: "The log pattern suggests a bursty or sustained CPU-intensive operation, hot loop, or insufficient capacity for the incoming workload.",
    steps: ["Capture a CPU profile during the next spike and isolate hot functions or processes.", "Check recent traffic, deployment, and batch-job changes that correlate with the incident.", "Rate-limit expensive work or add capacity while the underlying bottleneck is removed."],
  },
};

export function getIncidentPlaybook(failureType: FailureType) {
  return playbooks[failureType];
}

export function fallbackDiagnosis(failureType: FailureType, severity: Severity, message: string) {
  const playbook = getIncidentPlaybook(failureType);
  return `${playbook.title} Severity is ${severity}. ${playbook.cause} Evidence: ${message.slice(0, 240)}`;
}

export function syntheticLogs() {
  const base = new Date(Date.now() - 8 * 60_000);
  const entries = [
    ["INFO", "gateway request completed latency=84ms cpu usage=31% memory=54% disk=42%"],
    ["WARN", "payments retry observed latency=612ms upstream=ledger"],
    ["ERROR", "worker OutOfMemoryError: heap exhausted memory leak suspected memory=97%"],
    ["INFO", "scheduler tick completed latency=46ms cpu usage=28%"],
    ["CRITICAL", "archive writer ENOSPC: no space left on device disk failure disk=99%"],
    ["ERROR", "catalog request ETIMEDOUT after latency=4800ms network timeout dependency=search"],
    ["WARN", "api pod cpu spike detected cpu usage=98% load average=14.2"],
    ["INFO", "gateway request completed latency=93ms cpu usage=33% memory=55% disk=42%"],
    ["ERROR", "cache allocator retained objects memory leak memory=95% allocation failure"],
    ["INFO", "health check passed latency=18ms"],
  ] as const;

  return entries.map(([level, message], index) => {
    const timestamp = new Date(base.getTime() + index * 45_000).toISOString();
    return `${timestamp} ${level} service=platform-api ${message}`;
  }).join("\n");
}
