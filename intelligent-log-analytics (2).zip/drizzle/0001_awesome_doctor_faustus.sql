CREATE TABLE `analysisRuns` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sourceName` varchar(160) NOT NULL,
	`sourceType` enum('text','json','csv') NOT NULL,
	`totalLogs` int NOT NULL,
	`anomalyCount` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `analysisRuns_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `incidents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`analysisRunId` int NOT NULL,
	`eventTimestamp` varchar(64) NOT NULL,
	`level` varchar(24) NOT NULL,
	`severity` enum('critical','high','medium','low') NOT NULL,
	`failureType` enum('memory leak','disk failure','network timeout','CPU spike') NOT NULL,
	`confidence` int NOT NULL,
	`anomalyScore` varchar(24) NOT NULL,
	`logMessage` text NOT NULL,
	`diagnosis` text NOT NULL,
	`recommendations` json NOT NULL,
	`status` enum('open','investigating','resolved') NOT NULL DEFAULT 'open',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `incidents_id` PRIMARY KEY(`id`)
);
