import { int, json, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const analysisRuns = mysqlTable("analysisRuns", {
  id: int("id").autoincrement().primaryKey(),
  sourceName: varchar("sourceName", { length: 160 }).notNull(),
  sourceType: mysqlEnum("sourceType", ["text", "json", "csv"]).notNull(),
  totalLogs: int("totalLogs").notNull(),
  anomalyCount: int("anomalyCount").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const incidents = mysqlTable("incidents", {
  id: int("id").autoincrement().primaryKey(),
  analysisRunId: int("analysisRunId").notNull(),
  eventTimestamp: varchar("eventTimestamp", { length: 64 }).notNull(),
  level: varchar("level", { length: 24 }).notNull(),
  severity: mysqlEnum("severity", ["critical", "high", "medium", "low"]).notNull(),
  failureType: mysqlEnum("failureType", ["memory leak", "disk failure", "network timeout", "CPU spike"]).notNull(),
  confidence: int("confidence").notNull(),
  anomalyScore: varchar("anomalyScore", { length: 24 }).notNull(),
  modelPredictions: json("modelPredictions").$type<{
    isolationForest: { prediction: "anomaly"; decisionScore: number; anomalyScore: number; contamination: number };
    xgboost: { predictedClass: "memory leak" | "disk failure" | "network timeout" | "CPU spike"; confidence: number; probabilities: Record<string, number> };
  }>(),
  logMessage: text("logMessage").notNull(),
  diagnosis: text("diagnosis").notNull(),
  recommendations: json("recommendations").$type<string[]>().notNull(),
  status: mysqlEnum("status", ["open", "investigating", "resolved"]).default("open").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AnalysisRun = typeof analysisRuns.$inferSelect;
export type InsertAnalysisRun = typeof analysisRuns.$inferInsert;
export type Incident = typeof incidents.$inferSelect;
export type InsertIncident = typeof incidents.$inferInsert;
