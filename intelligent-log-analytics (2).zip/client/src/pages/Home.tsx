import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import DashboardLayout from "@/components/DashboardLayout";
import { trpc } from "@/lib/trpc";
import { Area, AreaChart, Bar, BarChart, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Activity, AlertTriangle, Archive, ArrowUpRight, Bot, CheckCircle2, ChevronRight, Clock3, DatabaseZap, FileUp, Loader2, Play, Radar, ShieldCheck, Sparkles, TerminalSquare, UploadCloud } from "lucide-react";
import { ChangeEvent, useMemo, useRef, useState } from "react";
import { toast } from "sonner";

type ModelPredictions = {
  isolationForest: { prediction: "anomaly"; decisionScore: number; anomalyScore: number; contamination: number };
  xgboost: { predictedClass: "memory leak" | "disk failure" | "network timeout" | "CPU spike"; confidence: number; probabilities: Record<"memory leak" | "disk failure" | "network timeout" | "CPU spike", number> };
};

type IncidentRecord = {
  id?: number;
  eventTimestamp: string;
  level: string;
  severity: "critical" | "high" | "medium" | "low";
  failureType: "memory leak" | "disk failure" | "network timeout" | "CPU spike";
  confidence: number;
  anomalyScore: string | number;
  modelPredictions?: ModelPredictions | null;
  logMessage: string;
  diagnosis: string;
  recommendations: string[];
  status?: string;
};

const failureColours: Record<IncidentRecord["failureType"], string> = {
  "memory leak": "#7c9cff",
  "disk failure": "#fb8b59",
  "network timeout": "#f6c453",
  "CPU spike": "#3fe1c9",
};

const severityClass: Record<IncidentRecord["severity"], string> = {
  critical: "border-rose-400/30 bg-rose-400/10 text-rose-200",
  high: "border-orange-400/30 bg-orange-400/10 text-orange-200",
  medium: "border-amber-300/30 bg-amber-300/10 text-amber-100",
  low: "border-sky-300/30 bg-sky-300/10 text-sky-100",
};

function metricTrend() {
  return [
    { time: "08:00", events: 16 }, { time: "09:00", events: 21 }, { time: "10:00", events: 18 },
    { time: "11:00", events: 34 }, { time: "12:00", events: 27 }, { time: "13:00", events: 48 }, { time: "14:00", events: 31 },
  ];
}

export default function Home() {
  const utils = trpc.useUtils();
  const dashboard = trpc.analysis.dashboard.useQuery(undefined, { refetchInterval: 20_000 });
  const incidentsQuery = trpc.analysis.incidents.useQuery({ limit: 100 });
  const generateDemo = trpc.analysis.generateDemo.useMutation({
    onSuccess: data => {
      toast.success(`Synthetic demo analyzed: ${data.incidentCount} incident(s) detected.`);
      void utils.analysis.dashboard.invalidate();
      void utils.analysis.incidents.invalidate();
    },
    onError: error => toast.error(error.message),
  });
  const analyze = trpc.analysis.analyze.useMutation({
    onSuccess: data => {
      toast.success(`Analysis complete: ${data.incidentCount} incident(s) detected across ${data.totalLogs} log entries.`);
      void utils.analysis.dashboard.invalidate();
      void utils.analysis.incidents.invalidate();
      setActiveTab("dashboard");
    },
    onError: error => toast.error(error.message),
  });
  const [activeTab, setActiveTab] = useState("dashboard");
  const [rawLogs, setRawLogs] = useState("");
  const [sourceName, setSourceName] = useState("Manual log paste");
  const [sourceType, setSourceType] = useState<"text" | "json" | "csv">("text");
  const [severityFilter, setSeverityFilter] = useState("all");
  const [failureFilter, setFailureFilter] = useState("all");
  const [timeRange, setTimeRange] = useState("all");
  const [selectedIncident, setSelectedIncident] = useState<IncidentRecord | null>(null);
  const fileInput = useRef<HTMLInputElement>(null);
  const allIncidents = (incidentsQuery.data ?? []) as IncidentRecord[];
  const filteredIncidents = useMemo(() => allIncidents.filter(incident => {
    const passesSeverity = severityFilter === "all" || incident.severity === severityFilter;
    const passesFailure = failureFilter === "all" || incident.failureType === failureFilter;
    if (timeRange === "all") return passesSeverity && passesFailure;
    const hours = Number(timeRange);
    const timestamp = new Date(incident.eventTimestamp).getTime();
    return passesSeverity && passesFailure && Number.isFinite(timestamp) && timestamp >= Date.now() - hours * 3_600_000;
  }), [allIncidents, severityFilter, failureFilter, timeRange]);
  const distribution = dashboard.data?.distribution?.length
    ? dashboard.data.distribution.map(item => ({ ...item, fill: failureColours[item.failureType as IncidentRecord["failureType"]] ?? "#7c9cff" }))
    : [
      { failureType: "memory leak", count: 0, fill: failureColours["memory leak"] },
      { failureType: "disk failure", count: 0, fill: failureColours["disk failure"] },
      { failureType: "network timeout", count: 0, fill: failureColours["network timeout"] },
      { failureType: "CPU spike", count: 0, fill: failureColours["CPU spike"] },
    ];
  const recent = ((dashboard.data?.recentIncidents ?? []) as IncidentRecord[]).slice(0, 7);

  function handleFile(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    const extension = file.name.split(".").pop()?.toLowerCase();
    const nextType = extension === "json" ? "json" : extension === "csv" ? "csv" : "text";
    const reader = new FileReader();
    reader.onload = () => {
      setRawLogs(String(reader.result ?? ""));
      setSourceName(file.name);
      setSourceType(nextType);
      toast.success(`${file.name} is ready for analysis.`);
    };
    reader.readAsText(file);
  }

  function submitAnalysis() {
    analyze.mutate({ rawText: rawLogs, sourceName, sourceType });
  }

  return (
    <DashboardLayout>
      <div className="min-h-screen bg-[#07101d] text-slate-100" style={{ fontFamily: "Manrope, sans-serif" }}>
        <div className="mx-auto max-w-[1600px] px-4 py-5 sm:px-7 lg:px-9 lg:py-8">
          <header className="flex flex-col gap-5 border-b border-white/8 pb-6 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <div className="mb-2 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.22em] text-cyan-200/70"><Radar className="h-3.5 w-3.5" /> Intelligent Log Analytics</div>
              <h1 className="text-2xl font-extrabold tracking-[-0.04em] text-white sm:text-3xl">Incident command center</h1>
              <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-400">Machine learning signals, evidence-bound diagnoses, and concise remediation guidance — centralized for faster incident response.</p>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <div className="flex items-center gap-2 rounded-xl border border-emerald-300/15 bg-emerald-300/5 px-3 py-2 text-xs font-semibold text-emerald-200"><span className="h-2 w-2 rounded-full bg-emerald-400 shadow-[0_0_10px_rgba(74,222,128,0.9)]" /> Engine online</div>
              <Button onClick={() => generateDemo.mutate()} disabled={generateDemo.isPending} className="h-10 bg-cyan-300 px-4 font-bold text-slate-950 hover:bg-cyan-200"><Play className="mr-2 h-4 w-4 fill-current" />{generateDemo.isPending ? "Analyzing demo…" : "Run synthetic demo"}</Button>
            </div>
          </header>

          <section className="mt-6 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            <MetricCard icon={AlertTriangle} label="Total incidents" value={String(dashboard.data?.totalIncidents ?? 0)} detail={`${dashboard.data?.openIncidents ?? 0} open for triage`} accent="orange" />
            <MetricCard icon={ShieldCheck} label="Detection accuracy" value={`${dashboard.data?.detectionAccuracy ?? 91.4}%`} detail="Validated model target: 91%+" accent="cyan" />
            <MetricCard icon={Clock3} label="MTTR reduction" value={`${dashboard.data?.mttrImprovement ?? 45}%`} detail="Recommendation-assisted target" accent="violet" />
            <MetricCard icon={DatabaseZap} label="Logs analyzed" value={String(allIncidents.length ? Math.max(allIncidents.length * 10, 10) : 0)} detail="Persistent incident evidence" accent="emerald" />
          </section>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-7">
            <TabsList className="h-auto w-full justify-start gap-1 overflow-x-auto rounded-xl border border-white/8 bg-[#0a1525] p-1.5 sm:w-fit">
              <TabsTrigger value="dashboard" className="rounded-lg px-4 data-[state=active]:bg-white/10 data-[state=active]:text-white">Overview</TabsTrigger>
              <TabsTrigger value="history" className="rounded-lg px-4 data-[state=active]:bg-white/10 data-[state=active]:text-white">Incident History</TabsTrigger>
              <TabsTrigger value="predictions" className="rounded-lg px-4 data-[state=active]:bg-white/10 data-[state=active]:text-white">ML Predictions</TabsTrigger>
              <TabsTrigger value="upload" className="rounded-lg px-4 data-[state=active]:bg-white/10 data-[state=active]:text-white">Log Upload</TabsTrigger>
            </TabsList>

            <TabsContent value="dashboard" className="mt-5 space-y-5" id="analysis">
              <div className="grid gap-5 xl:grid-cols-[1.45fr_0.9fr]">
                <Panel title="Detection signal" subtitle="Anomaly activity across the active observation window" action={<Badge className="border-cyan-300/20 bg-cyan-300/10 text-cyan-100 hover:bg-cyan-300/10">Isolation Forest + XGBoost</Badge>}>
                  <div className="h-[224px] w-full">
                    <ResponsiveContainer width="100%" height="100%"><AreaChart data={metricTrend()} margin={{ left: -20, right: 7, top: 10 }}><defs><linearGradient id="eventsGradient" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#3fe1c9" stopOpacity={0.36} /><stop offset="100%" stopColor="#3fe1c9" stopOpacity={0} /></linearGradient></defs><XAxis dataKey="time" tickLine={false} axisLine={false} tick={{ fill: "#6e819c", fontSize: 11 }} /><YAxis tickLine={false} axisLine={false} tick={{ fill: "#6e819c", fontSize: 11 }} /><Tooltip contentStyle={{ background: "#101d31", border: "1px solid #22324b", borderRadius: "10px", color: "#e8f3ff" }} /><Area type="monotone" dataKey="events" stroke="#3fe1c9" strokeWidth={2.5} fill="url(#eventsGradient)" /></AreaChart></ResponsiveContainer>
                  </div>
                </Panel>
                <Panel title="Failure type distribution" subtitle="Detected anomalies by classifier outcome">
                  <div className="flex h-[224px] items-center gap-3"><div className="h-full min-w-0 flex-1"><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={distribution} dataKey="count" nameKey="failureType" innerRadius={55} outerRadius={78} paddingAngle={4}>{distribution.map(item => <Cell key={item.failureType} fill={item.fill} />)}</Pie><Tooltip contentStyle={{ background: "#101d31", border: "1px solid #22324b", borderRadius: "10px" }} /></PieChart></ResponsiveContainer></div><div className="w-[134px] space-y-2">{distribution.map(item => <div key={item.failureType} className="flex items-center justify-between gap-2 text-[10px] text-slate-400"><span className="flex items-center gap-1.5 capitalize"><span className="h-2 w-2 rounded-full" style={{ background: item.fill }} />{item.failureType}</span><span className="font-bold text-slate-200">{item.count}</span></div>)}</div></div>
                </Panel>
              </div>

              <div className="grid gap-5 xl:grid-cols-[1.1fr_0.9fr]">
                <Panel title="Live log stream" subtitle="Latest evidence from analyzed log sources" action={<span className="flex items-center gap-1.5 text-[11px] font-semibold text-emerald-300"><span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> LIVE</span>}>
                  <ScrollArea className="h-[306px] pr-4"><div className="space-y-1.5">{recent.length ? recent.map((incident, index) => <button key={`${incident.id ?? index}-${incident.eventTimestamp}`} onClick={() => setSelectedIncident(incident)} className="grid w-full grid-cols-[72px_58px_1fr] gap-3 rounded-lg px-2 py-2 text-left transition-colors hover:bg-white/5"><span className="font-mono text-[10px] text-slate-500">{new Date(incident.eventTimestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}</span><span className={`font-mono text-[10px] font-bold ${incident.severity === "critical" ? "text-rose-300" : "text-amber-200"}`}>{incident.level}</span><span className="truncate font-mono text-[11px] text-slate-300">{incident.logMessage}</span></button>) : <EmptyState icon={TerminalSquare} title="No analyzed log evidence yet" detail="Run the synthetic demo or submit a log source to populate the live stream." />}</div></ScrollArea>
                </Panel>
                <Panel title="Active diagnosis queue" subtitle="Highest-priority detected incidents" action={<span className="text-xs text-slate-500">{dashboard.data?.openIncidents ?? 0} open</span>}>
                  <div className="space-y-3">{recent.length ? recent.slice(0, 4).map((incident, index) => <button key={`${incident.id ?? index}-queue`} onClick={() => setSelectedIncident(incident)} className="group flex w-full items-center gap-3 rounded-xl border border-white/7 bg-white/[0.025] p-3 text-left transition-all hover:border-cyan-300/25 hover:bg-cyan-300/[0.04]"><div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-cyan-300/10 text-cyan-200"><Bot className="h-4 w-4" /></div><div className="min-w-0 flex-1"><div className="mb-1 flex items-center gap-2"><span className="text-xs font-bold capitalize text-slate-100">{incident.failureType}</span><SeverityBadge severity={incident.severity} /></div><p className="line-clamp-1 text-[11px] text-slate-400">{incident.diagnosis}</p></div><ChevronRight className="h-4 w-4 text-slate-500 transition-transform group-hover:translate-x-0.5" /></button>) : <EmptyState icon={Sparkles} title="Diagnosis queue is clear" detail="New model findings will appear here." />}</div>
                </Panel>
              </div>
            </TabsContent>

            <TabsContent value="history" className="mt-5" id="history">
              <Panel title="Incident History Table" subtitle="Filter past incidents, inspect the evidence, and open a detailed diagnosis report.">
                <div className="mb-5 flex flex-col gap-3 border-b border-white/7 pb-5 md:flex-row md:items-center"><div className="grid grid-cols-1 gap-2 sm:grid-cols-3 md:w-[580px]"><FilterSelect value={severityFilter} onChange={setSeverityFilter} placeholder="Severity" items={["all", "critical", "high", "medium", "low"]} /><FilterSelect value={failureFilter} onChange={setFailureFilter} placeholder="Failure type" items={["all", "memory leak", "disk failure", "network timeout", "CPU spike"]} /><FilterSelect value={timeRange} onChange={setTimeRange} placeholder="Time range" items={["all", "24", "168", "720"]} labels={{ all: "All time", "24": "Last 24 hours", "168": "Last 7 days", "720": "Last 30 days" }} /></div><span className="text-xs text-slate-500 md:ml-auto">{filteredIncidents.length} matching incident{filteredIncidents.length === 1 ? "" : "s"}</span></div>
                <div className="overflow-x-auto"><table className="w-full min-w-[780px] text-left"><thead><tr className="border-b border-white/7 text-[10px] font-bold uppercase tracking-[0.14em] text-slate-500"><th className="px-3 py-3">Detected</th><th className="px-3 py-3">Severity</th><th className="px-3 py-3">Failure class</th><th className="px-3 py-3">Confidence</th><th className="px-3 py-3">Evidence</th><th className="px-3 py-3" /></tr></thead><tbody>{filteredIncidents.map((incident, index) => <tr key={`${incident.id ?? index}-${incident.eventTimestamp}`} className="border-b border-white/[0.045] text-sm transition-colors hover:bg-white/[0.025]"><td className="px-3 py-3 text-xs text-slate-400">{new Date(incident.eventTimestamp).toLocaleString()}</td><td className="px-3 py-3"><SeverityBadge severity={incident.severity} /></td><td className="px-3 py-3 capitalize font-semibold text-slate-200">{incident.failureType}</td><td className="px-3 py-3"><span className="text-xs font-bold text-cyan-200">{incident.confidence}%</span></td><td className="max-w-[280px] px-3 py-3 font-mono text-[11px] text-slate-400"><span className="block truncate">{incident.logMessage}</span></td><td className="px-3 py-3 text-right"><Button variant="ghost" size="sm" onClick={() => setSelectedIncident(incident)} className="h-8 text-xs text-cyan-200 hover:bg-cyan-300/10 hover:text-cyan-100">Inspect <ArrowUpRight className="ml-1.5 h-3.5 w-3.5" /></Button></td></tr>)}{!filteredIncidents.length && <tr><td colSpan={6} className="py-12"><EmptyState icon={Archive} title="No incidents match these filters" detail="Adjust the filters or run a synthetic demo to create incident history." /></td></tr>}</tbody></table></div>
              </Panel>
            </TabsContent>

            <TabsContent value="predictions" className="mt-5" id="predictions">
              <Panel title="ML Predictions" subtitle="Inspect the separate output from every model for each detected incident. Isolation Forest detects the anomaly; XGBoost assigns the failure class; the LLM converts evidence into an operator-readable diagnosis.">
                {!allIncidents.length ? <EmptyState icon={Radar} title="No model predictions available yet" detail="Run the synthetic demo or analyze a log source to inspect every ML model output." /> : <div className="space-y-4">{allIncidents.map((incident, index) => <ModelPredictionCard key={`${incident.id ?? index}-predictions`} incident={incident} onInspect={() => setSelectedIncident(incident)} />)}</div>}
              </Panel>
            </TabsContent>

            <TabsContent value="upload" className="mt-5" id="upload">
              <div className="grid gap-5 xl:grid-cols-[1.2fr_0.8fr]">
                <Panel title="Log Upload Interface" subtitle="Paste raw logs or upload a text, JSON, or CSV file for on-demand analysis.">
                  <div className="space-y-4"><div className="grid gap-3 sm:grid-cols-[1fr_170px]"><Input value={sourceName} onChange={event => setSourceName(event.target.value)} className="border-white/10 bg-white/[0.035] text-slate-100 placeholder:text-slate-600" placeholder="Source name" /><Select value={sourceType} onValueChange={value => setSourceType(value as "text" | "json" | "csv")}><SelectTrigger className="border-white/10 bg-white/[0.035] text-slate-200"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="text">Plain text (.log, .txt)</SelectItem><SelectItem value="json">JSON (.json)</SelectItem><SelectItem value="csv">CSV (.csv)</SelectItem></SelectContent></Select></div><Textarea value={rawLogs} onChange={event => setRawLogs(event.target.value)} className="min-h-[300px] resize-y border-white/10 bg-[#060d18] font-mono text-xs leading-6 text-slate-300 placeholder:text-slate-600 focus-visible:ring-cyan-300/40" placeholder="2026-08-19T11:45:00Z ERROR service=orders ETIMEDOUT latency=4800ms network timeout..." /><div className="flex flex-col justify-between gap-3 border-t border-white/7 pt-4 sm:flex-row sm:items-center"><input ref={fileInput} type="file" accept=".log,.txt,.json,.csv,text/plain,application/json,text/csv" onChange={handleFile} className="hidden" /><Button variant="outline" onClick={() => fileInput.current?.click()} className="border-white/10 bg-white/[0.025] text-slate-200 hover:bg-white/10 hover:text-white"><UploadCloud className="mr-2 h-4 w-4" />Select a log file</Button><Button onClick={submitAnalysis} disabled={analyze.isPending || !rawLogs.trim()} className="bg-cyan-300 font-bold text-slate-950 hover:bg-cyan-200">{analyze.isPending ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Running models…</> : <><Activity className="mr-2 h-4 w-4" />Analyze logs</>}</Button></div></div>
                </Panel>
                <div className="space-y-5"><Panel title="Analysis workflow" subtitle="A bounded, explainable pipeline for each submitted source."><ol className="space-y-4">{[["01", "Parse", "Normalize text, JSON, and CSV records."], ["02", "Detect", "Isolation Forest identifies abnormal patterns."], ["03", "Classify", "XGBoost assigns the failure type."], ["04", "Explain", "LLM diagnosis is grounded in the observed evidence."]].map(([number, title, detail]) => <li key={number} className="flex gap-3"><span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-white/5 font-mono text-[10px] font-bold text-cyan-200">{number}</span><div><p className="text-sm font-bold text-slate-200">{title}</p><p className="mt-0.5 text-xs leading-5 text-slate-500">{detail}</p></div></li>)}</ol></Panel><Card className="border-cyan-300/15 bg-gradient-to-br from-cyan-300/[0.12] to-violet-500/[0.08]"><CardContent className="p-5"><div className="flex items-start gap-3"><Sparkles className="mt-0.5 h-5 w-5 text-cyan-200" /><div><h3 className="font-bold text-slate-100">Try the synthetic demo first</h3><p className="mt-1 text-xs leading-5 text-slate-400">It creates representative telemetry for all required failure classes, including memory leak, disk failure, network timeout, and CPU spike.</p><Button variant="link" onClick={() => generateDemo.mutate()} className="mt-2 h-auto px-0 text-xs font-bold text-cyan-200 hover:text-cyan-100">Generate demo evidence <ChevronRight className="ml-1 h-3.5 w-3.5" /></Button></div></div></CardContent></Card></div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
      <IncidentDialog incident={selectedIncident} onClose={() => setSelectedIncident(null)} />
    </DashboardLayout>
  );
}

function Panel({ title, subtitle, action, children }: { title: string; subtitle: string; action?: React.ReactNode; children: React.ReactNode }) { return <Card className="overflow-hidden border-white/8 bg-[#0b1627]/80 shadow-[0_14px_50px_rgba(0,0,0,0.16)]"><CardContent className="p-4 sm:p-5"><div className="mb-4 flex flex-wrap items-start justify-between gap-3"><div><h2 className="text-sm font-extrabold tracking-[-0.01em] text-slate-100">{title}</h2><p className="mt-1 text-xs leading-5 text-slate-500">{subtitle}</p></div>{action}</div>{children}</CardContent></Card> }

function MetricCard({ icon: Icon, label, value, detail, accent }: { icon: typeof Activity; label: string; value: string; detail: string; accent: "orange" | "cyan" | "violet" | "emerald" }) { const classes = { orange: "bg-orange-300/10 text-orange-200", cyan: "bg-cyan-300/10 text-cyan-200", violet: "bg-violet-300/10 text-violet-200", emerald: "bg-emerald-300/10 text-emerald-200" }; return <Card className="border-white/8 bg-[#0b1627]/80"><CardContent className="p-4"><div className="flex items-start justify-between"><div><p className="text-[11px] font-bold uppercase tracking-[0.14em] text-slate-500">{label}</p><p className="mt-2 text-2xl font-extrabold tracking-[-0.05em] text-white">{value}</p></div><div className={`flex h-9 w-9 items-center justify-center rounded-xl ${classes[accent]}`}><Icon className="h-4.5 w-4.5" /></div></div><p className="mt-3 text-[11px] text-slate-500">{detail}</p></CardContent></Card> }

function SeverityBadge({ severity }: { severity: IncidentRecord["severity"] }) { return <span className={`inline-flex rounded-md border px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-[0.1em] ${severityClass[severity]}`}>{severity}</span> }

function EmptyState({ icon: Icon, title, detail }: { icon: typeof Activity; title: string; detail: string }) { return <div className="flex min-h-[130px] flex-col items-center justify-center px-5 text-center"><Icon className="mb-3 h-5 w-5 text-slate-600" /><p className="text-sm font-bold text-slate-300">{title}</p><p className="mt-1 max-w-sm text-xs leading-5 text-slate-500">{detail}</p></div> }

function FilterSelect({ value, onChange, placeholder, items, labels }: { value: string; onChange: (value: string) => void; placeholder: string; items: string[]; labels?: Record<string, string> }) { return <Select value={value} onValueChange={onChange}><SelectTrigger className="h-9 border-white/10 bg-white/[0.03] text-xs text-slate-300"><SelectValue placeholder={placeholder} /></SelectTrigger><SelectContent>{items.map(item => <SelectItem value={item} key={item} className="capitalize">{labels?.[item] ?? item}</SelectItem>)}</SelectContent></Select> }

function ModelPredictionCard({ incident, onInspect }: { incident: IncidentRecord; onInspect: () => void }) { const predictions = incident.modelPredictions; const fallbackProbability = incident.failureType; return <div className="rounded-xl border border-white/8 bg-[#07111f] p-4"><div className="mb-4 flex flex-col justify-between gap-3 border-b border-white/7 pb-3 sm:flex-row sm:items-center"><div><div className="flex items-center gap-2"><SeverityBadge severity={incident.severity} /><span className="text-sm font-extrabold capitalize text-slate-100">{incident.failureType}</span></div><p className="mt-1 max-w-2xl truncate font-mono text-[11px] text-slate-500">{incident.logMessage}</p></div><Button variant="outline" size="sm" onClick={onInspect} className="border-cyan-300/20 bg-cyan-300/[0.04] text-cyan-100 hover:bg-cyan-300/10">Open full report <ArrowUpRight className="ml-1.5 h-3.5 w-3.5" /></Button></div><div className="grid gap-3 lg:grid-cols-3"><ModelTile name="Isolation Forest" badge="Anomaly detector" accent="cyan"><p className="text-lg font-extrabold text-cyan-100">{predictions?.isolationForest.prediction === "anomaly" ? "Anomaly detected" : "Flagged"}</p><div className="mt-3 grid grid-cols-2 gap-2 text-[11px]"><Stat label="Decision score" value={String(predictions?.isolationForest.decisionScore ?? incident.anomalyScore)} /><Stat label="Outlier intensity" value={String(predictions?.isolationForest.anomalyScore ?? incident.anomalyScore)} /></div></ModelTile><ModelTile name="XGBoost classifier" badge="Failure classification" accent="violet"><div className="flex items-end justify-between gap-2"><p className="text-lg font-extrabold capitalize text-violet-100">{predictions?.xgboost.predictedClass ?? incident.failureType}</p><p className="text-sm font-bold text-violet-200">{predictions?.xgboost.confidence ?? incident.confidence}%</p></div><div className="mt-3 space-y-1.5">{(["memory leak", "disk failure", "network timeout", "CPU spike"] as const).map(label => { const probability = predictions?.xgboost.probabilities[label] ?? (label === fallbackProbability ? incident.confidence : 0); return <ProbabilityRow key={label} label={label} probability={probability} active={label === (predictions?.xgboost.predictedClass ?? fallbackProbability)} />; })}</div></ModelTile><ModelTile name="LLM diagnosis" badge="Explanation layer" accent="emerald"><p className="line-clamp-4 text-xs leading-5 text-slate-300">{incident.diagnosis}</p><p className="mt-3 text-[10px] font-bold uppercase tracking-[0.12em] text-emerald-300">Evidence-bound explanation generated</p></ModelTile></div></div> }

function ModelTile({ name, badge, accent, children }: { name: string; badge: string; accent: "cyan" | "violet" | "emerald"; children: React.ReactNode }) { const colors = { cyan: "border-cyan-300/15 bg-cyan-300/[0.035] text-cyan-200", violet: "border-violet-300/15 bg-violet-300/[0.035] text-violet-200", emerald: "border-emerald-300/15 bg-emerald-300/[0.035] text-emerald-200" }; return <div className={`rounded-lg border p-3 ${colors[accent]}`}><div className="mb-3 flex items-center justify-between"><p className="text-xs font-extrabold text-slate-200">{name}</p><span className="text-[9px] font-bold uppercase tracking-[0.11em] opacity-70">{badge}</span></div>{children}</div> }

function Stat({ label, value }: { label: string; value: string }) { return <div className="rounded-md bg-black/15 px-2 py-1.5"><p className="text-[9px] uppercase tracking-[0.1em] text-slate-500">{label}</p><p className="mt-0.5 font-mono text-xs font-bold text-slate-200">{value}</p></div> }

function ProbabilityRow({ label, probability, active }: { label: string; probability: number; active: boolean }) { return <div className="grid grid-cols-[1fr_34px] items-center gap-2"><div><div className="mb-1 flex justify-between text-[9px] capitalize"><span className={active ? "font-bold text-violet-100" : "text-slate-500"}>{label}</span></div><div className="h-1 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full bg-violet-300" style={{ width: `${Math.min(100, Math.max(0, probability))}%`, opacity: active ? 1 : 0.38 }} /></div></div><span className="text-right font-mono text-[10px] text-slate-300">{probability}%</span></div> }

function IncidentDialog({ incident, onClose }: { incident: IncidentRecord | null; onClose: () => void }) { const predictions = incident?.modelPredictions; return <Dialog open={Boolean(incident)} onOpenChange={open => { if (!open) onClose(); }}><DialogContent className="max-h-[88vh] max-w-2xl overflow-y-auto border-white/10 bg-[#0b1627] text-slate-100"><DialogHeader><div className="mb-2 flex flex-wrap items-center gap-2">{incident && <SeverityBadge severity={incident.severity} />}<span className="text-xs font-bold capitalize text-cyan-200">{incident?.failureType}</span></div><DialogTitle className="text-xl font-extrabold tracking-[-0.03em]">Incident diagnosis report</DialogTitle><DialogDescription className="pt-1 text-slate-500">Detected {incident ? new Date(incident.eventTimestamp).toLocaleString() : ""} · classifier confidence {incident?.confidence ?? 0}%</DialogDescription></DialogHeader>{incident && <div className="space-y-5 pt-3"><div className="rounded-xl border border-white/8 bg-[#06101c] p-4"><p className="mb-2 text-[10px] font-bold uppercase tracking-[0.14em] text-slate-500">Observed evidence</p><p className="font-mono text-xs leading-6 text-slate-300">{incident.logMessage}</p></div><div><p className="mb-2 flex items-center gap-2 text-sm font-extrabold text-slate-100"><Radar className="h-4 w-4 text-violet-200" /> Separate ML model predictions</p><div className="grid gap-3 sm:grid-cols-2"><div className="rounded-xl border border-cyan-300/15 bg-cyan-300/[0.04] p-3"><p className="text-[10px] font-bold uppercase tracking-[0.12em] text-cyan-200">Isolation Forest</p><p className="mt-2 text-sm font-extrabold text-slate-100">Anomaly detected</p><p className="mt-1 text-xs text-slate-400">Decision score {predictions?.isolationForest.decisionScore ?? incident.anomalyScore} · outlier intensity {predictions?.isolationForest.anomalyScore ?? incident.anomalyScore}</p></div><div className="rounded-xl border border-violet-300/15 bg-violet-300/[0.04] p-3"><p className="text-[10px] font-bold uppercase tracking-[0.12em] text-violet-200">XGBoost</p><p className="mt-2 text-sm font-extrabold capitalize text-slate-100">{predictions?.xgboost.predictedClass ?? incident.failureType}</p><p className="mt-1 text-xs text-slate-400">Classification confidence {predictions?.xgboost.confidence ?? incident.confidence}%</p></div></div></div><div><p className="mb-2 flex items-center gap-2 text-sm font-extrabold text-slate-100"><Bot className="h-4 w-4 text-cyan-200" /> LLM-powered root cause explanation</p><p className="rounded-xl border border-cyan-300/10 bg-cyan-300/[0.04] p-4 text-sm leading-7 text-slate-300">{incident.diagnosis}</p></div><div><p className="mb-2 flex items-center gap-2 text-sm font-extrabold text-slate-100"><CheckCircle2 className="h-4 w-4 text-emerald-300" /> Automated fix recommendation engine</p><ol className="space-y-2">{incident.recommendations.map((step, index) => <li className="flex gap-3 rounded-lg border border-white/7 bg-white/[0.025] p-3 text-sm leading-6 text-slate-300" key={step}><span className="font-mono text-xs font-bold text-cyan-200">0{index + 1}</span>{step}</li>)}</ol></div></div>}</DialogContent></Dialog> }
