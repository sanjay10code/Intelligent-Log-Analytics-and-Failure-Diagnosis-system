import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
  useSidebar,
} from "@/components/ui/sidebar";
import { useIsMobile } from "@/hooks/useMobile";
import { Activity, Archive, FileUp, LayoutDashboard, PanelLeft } from "lucide-react";
import { CSSProperties, useEffect, useRef, useState } from "react";
import { useLocation } from "wouter";

const menuItems = [
  { icon: LayoutDashboard, label: "Command Center", path: "/" },
  { icon: Activity, label: "Live Analysis", path: "/#analysis" },
  { icon: Archive, label: "Incident History", path: "/#history" },
  { icon: FileUp, label: "Log Upload", path: "/#upload" },
];

const SIDEBAR_WIDTH_KEY = "sidebar-width";
const DEFAULT_WIDTH = 262;
const MIN_WIDTH = 210;
const MAX_WIDTH = 360;

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [sidebarWidth, setSidebarWidth] = useState(() => {
    const saved = localStorage.getItem(SIDEBAR_WIDTH_KEY);
    return saved ? parseInt(saved, 10) : DEFAULT_WIDTH;
  });

  useEffect(() => {
    localStorage.setItem(SIDEBAR_WIDTH_KEY, sidebarWidth.toString());
  }, [sidebarWidth]);

  return (
    <SidebarProvider style={{ "--sidebar-width": `${sidebarWidth}px` } as CSSProperties}>
      <DashboardLayoutContent setSidebarWidth={setSidebarWidth}>{children}</DashboardLayoutContent>
    </SidebarProvider>
  );
}

function DashboardLayoutContent({ children, setSidebarWidth }: { children: React.ReactNode; setSidebarWidth: (width: number) => void }) {
  const [location, setLocation] = useLocation();
  const { state, toggleSidebar } = useSidebar();
  const isCollapsed = state === "collapsed";
  const [isResizing, setIsResizing] = useState(false);
  const sidebarRef = useRef<HTMLDivElement>(null);
  const isMobile = useIsMobile();
  const activeMenuItem = menuItems.find(item => item.path === location) ?? menuItems[0];

  useEffect(() => {
    const handleMouseMove = (event: MouseEvent) => {
      if (!isResizing) return;
      const sidebarLeft = sidebarRef.current?.getBoundingClientRect().left ?? 0;
      const width = event.clientX - sidebarLeft;
      if (width >= MIN_WIDTH && width <= MAX_WIDTH) setSidebarWidth(width);
    };
    const handleMouseUp = () => setIsResizing(false);
    if (isResizing) {
      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
      document.body.style.cursor = "col-resize";
      document.body.style.userSelect = "none";
    }
    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    };
  }, [isResizing, setSidebarWidth]);

  function navigate(path: string) {
    if (path.startsWith("/#")) {
      document.querySelector(path.slice(1))?.scrollIntoView({ behavior: "smooth", block: "start" });
      return;
    }
    setLocation(path);
  }

  return (
    <>
      <div className="relative" ref={sidebarRef}>
        <Sidebar collapsible="icon" className="border-r border-white/8 bg-[#091221] text-slate-300" disableTransition={isResizing}>
          <SidebarHeader className="h-20 justify-center border-b border-white/8">
            <div className="flex w-full items-center gap-3 px-3">
              <button onClick={toggleSidebar} className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-white/5 hover:text-white focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-200" aria-label="Toggle navigation"><PanelLeft className="h-4 w-4" /></button>
              {!isCollapsed && <div className="min-w-0"><span className="block truncate text-sm font-extrabold tracking-tight text-slate-100">SignalForge</span><span className="block pt-0.5 text-[9px] font-bold uppercase tracking-[0.18em] text-cyan-200/60">Observability</span></div>}
            </div>
          </SidebarHeader>
          <SidebarContent className="gap-0 pt-3">
            <SidebarMenu className="space-y-1 px-2">
              {menuItems.map(item => {
                const isActive = item.path === "/" && location === "/";
                return <SidebarMenuItem key={item.path}><SidebarMenuButton isActive={isActive} onClick={() => navigate(item.path)} tooltip={item.label} className="h-11 font-medium text-slate-400 transition-all hover:bg-white/5 hover:text-slate-100 data-[active=true]:bg-cyan-300/10 data-[active=true]:text-cyan-100"><item.icon className="h-4 w-4" /><span>{item.label}</span></SidebarMenuButton></SidebarMenuItem>;
              })}
            </SidebarMenu>
          </SidebarContent>
          <SidebarFooter className="p-3">
            <div className="rounded-xl border border-cyan-300/10 bg-cyan-300/[0.05] px-3 py-3 group-data-[collapsible=icon]:px-2">
              <p className="text-[9px] font-bold uppercase tracking-[0.16em] text-cyan-200/60 group-data-[collapsible=icon]:hidden">System posture</p>
              <div className="mt-1 flex items-center gap-2 group-data-[collapsible=icon]:justify-center"><span className="h-2 w-2 rounded-full bg-emerald-400 shadow-[0_0_10px_rgba(74,222,128,0.9)]" /><span className="text-xs font-semibold text-emerald-200 group-data-[collapsible=icon]:hidden">Analysis ready</span></div>
            </div>
          </SidebarFooter>
        </Sidebar>
        <div className={`absolute right-0 top-0 z-50 h-full w-1 cursor-col-resize transition-colors hover:bg-cyan-300/30 ${isCollapsed ? "hidden" : ""}`} onMouseDown={() => setIsResizing(true)} />
      </div>
      <SidebarInset>
        {isMobile && <div className="sticky top-0 z-40 flex h-14 items-center border-b border-white/8 bg-[#091221]/95 px-2 backdrop-blur"><SidebarTrigger className="h-9 w-9 rounded-lg text-slate-300" /><span className="ml-2 text-sm font-bold text-slate-100">{activeMenuItem.label}</span></div>}
        <main className="min-w-0 flex-1">{children}</main>
      </SidebarInset>
    </>
  );
}
